/*************************************************************************
	CryGame Source File.
	Copyright (C), Crytek Studios, 2001-2004.
 -------------------------------------------------------------------------
	$Id$
	$DateTime$

 -------------------------------------------------------------------------
	History:
	- 20:7:2004   11:07 : Created by Marco Koegler

*************************************************************************/
#include "StdAfx.h"

// TODO: reference any additional headers you need in StdAfx.H
// and not in this file
