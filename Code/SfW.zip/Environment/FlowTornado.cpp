// -------------------------------------------------------------------------
// Crytek Source File.
// Copyright (C) Crytek GmbH, 2001-2008.
// -------------------------------------------------------------------------
#include "StdAfx.h"
#include "FlowTornado.h"

REGISTER_FLOW_NODE("Crysis:TornadoWander", CFlowTornadoWander);
