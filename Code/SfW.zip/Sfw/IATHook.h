
#pragma once
namespace sfw {
int IATHookByAddress( void *module, const void *pFunc, void *pNewFunc );
}
