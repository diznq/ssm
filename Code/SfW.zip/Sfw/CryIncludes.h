#include <CryModuleDefs.h>
#include <platform.h>

#include <I3DEngine.h>
#include <IGameFramework.h>
#include <IGameRulesSystem.h>
#include <ISystem.h>
#include <IConsole.h>
#include <IActorSystem.h>
