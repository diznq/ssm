// -------------------------------------------------------------------------
// Crytek Source File.
// Copyright (C) Crytek GmbH, 2001-2008.
// -------------------------------------------------------------------------
#include "StdAfx.h"
#include "FlowItemAnimation.h"

REGISTER_FLOW_NODE("Crysis:ItemAnimation", CFlowItemAnimation);
REGISTER_FLOW_NODE("Crysis:OffHandAnimation", CFlowOffhandAnimation);
