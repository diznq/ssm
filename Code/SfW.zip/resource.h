//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GameDll.rc
//
#define VS_VERSION_INFO                 1
#define IDC_CURSOR1                     101
#define IDI_ICON1                       102
#define IDB_CRYSIS                      103
#define IDB_HEALTH                      104
#define IDB_ENERGY                      105
#define IDB_GRENADE_SMOKE               106
#define IDB_GRENADE_EXPLOSIVE           107
#define IDB_GRENADE_FLASHBANG           108
#define IDB_GRENADE_NANO                109
#define IDB_GRENADE_SELECT              111
#define IDB_ITEM_LAW                    112
#define IDB_ITEM_FY71                   113
#define IDB_ITEM_DSG1                   114
#define IDB_ITEM_GAUSS                  115
#define IDB_ITEM_HURRICANE              116
#define IDB_ITEM_SCAR                   117
#define IDB_ITEM_SHOTGUN                118
#define IDB_ITEM_TACGUN                 119
#define IDB_ITEM_SMG                    120
#define IDB_ITEM_SOCOM                  121
#define IDB_SUIT_STRENGTH               122
#define IDB_SUIT_ARMOR                  123
#define IDB_SUIT_CLOAK                  124
#define IDB_SUIT_SPEED                  125
#define IDB_BITMAP1                     126
#define IDB_OBJECTIVE                   127
#define IDB_GRENADELAUNC                135
#define IDB_LOCKPICK                    137
#define IDB_DUALSOCOM                   138
#define IDB_ITEM_DUALSOCOM              138
#define IDB_ITEM_FISTS                  141
#define IDB_ITEM_MOAC                   142
#define IDB_ITEM_MOAR                   143
#define IDB_ITEM_RADARKIT               159
#define IDB_ITEM_C4BLOCK                160
#define IDB_ITEM_LOCKPICKKIT            161
#define IDB_ITEM_REPAIRTOOL             162
#define IDB_ITEM_CLAY_MORE              163
#define IDB_ITEM_MINE                   167
#define IDB_VEHICLE_LTVUS               168
#define IDB_VEHICLE_TANK                169
#define IDB_VEHICLE_TRUCK               170
#define IDB_VEHICLE_APC                 171
#define IDB_VEHICLE_BOAT                173
#define IDB_BITMAP2                     174
#define IDB_VEHICLE_HELICOPTER          174

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        175
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
